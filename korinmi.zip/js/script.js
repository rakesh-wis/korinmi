// home page carousel
$("#banner-carousel").owlCarousel({
  loop: true,
  margin: 0,
  dots: true,
  nav: false,
  dotsEach: true,
  autoplay: true,
  autoplayTimeout: 4000,
  animateOut: "slideOutDown",
  animateIn: "flipInX",
  items: 1,
  smartSpeed: 450,
});

$("#ba_slider").owlCarousel({
  loop: true,
  margin: 0,
  dots: true,
  nav: false,
  dotsEach: true,
  autoplay: true,
  autoplayTimeout: 4000,
  animateOut: "slideOutDown",
  animateIn: "flipInX",
  items: 1,
  smartSpeed: 450,
});
$("#customized-treatment").owlCarousel({
  loop: true,
  margin: 30,
  dots: false,
  nav: true,
  navText: [
    "<div class='nav-button prev text-black'><iconify-icon icon='flowbite:angle-left-outline'></iconify-icon></div>",
    "<div class='nav-button next text-black'><iconify-icon icon='flowbite:angle-right-outline'></iconify-icon></div>",
  ],
  dotsEach: true,
  autoplay: true,
  responsive: {
    0: {
      items: 1.5,
      nav: false,
      center:true
    },
    800: {
      items: 2,
      nav: false,
    },
    1000: {
      items: 3,
      nav: true,
    },
  },
});
$("#treatment_slider").owlCarousel({
  loop: true,
  margin: 10,
  dots: false,
  nav: false,
  dotsEach: true,
  autoplay: true,
  rtl: true,
  autoplaySpeed: 6200,
  //   autoplayTimeout: 2200,
  autoplayHoverPause: false,
  slideTransition: "linear",
  responsive: {
    0: {
      items: 1,
    },
    800: {
      items: 2,
    },
    1000: {
      items: 3,
    },
  },
});

$(window).scroll(function () {
  if ($(window).scrollTop() >= 150) {
    $("header").addClass("fixed-header");
  } else {
    $("header").removeClass("fixed-header");
  }
});
function myFunction(x) {
  x.classList.toggle("change");
}
